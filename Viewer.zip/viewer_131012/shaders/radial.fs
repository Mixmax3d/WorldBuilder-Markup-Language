float exposure = 0.0034;
float decay =1;
float density = 0.84;
float weight = 5.65;
uniform vec2 lightPositionOnScreen;
uniform sampler2D environment;
uniform sampler2D sky;
const int NUM_SAMPLES = 75 ;
varying vec2 UV;
void main()
{   
  
   gl_FragColor = vec4(1);
  
}